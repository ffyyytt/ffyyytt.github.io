import cv2
import ast
import webcolors

import numpy as np

from pwn import *
from PIL import Image
from pyzbar import pyzbar
from pyMorseTranslator import translator

asciicodes = [' ','!','"','#','$','%','&amp;','','(',')','*','+',',','-','.','/',
          '0','1','2','3','4','5','6','7','8','9',':',';','&lt;','=','&gt;','?','@',
          'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q',
          'r','s','t','u','v','w','x','y','z','[','\\',']','^','_', ":", ",", ' ']

brailles = ['⠀','⠮','⠐','⠼','⠫','⠩','⠯','⠄','⠷','⠾','⠡','⠬','⠠','⠤','⠨','⠌','⠴','⠂','⠆','⠒','⠲','⠢',
        '⠖','⠶','⠦','⠔','⠱','⠰','⠣','⠿','⠜','⠹','⠈','⠁','⠃','⠉','⠙','⠑','⠋','⠛','⠓','⠊','⠚','⠅',
        '⠇','⠍','⠝','⠕','⠏','⠟','⠗','⠎','⠞','⠥','⠧','⠺','⠭','⠽','⠵','⠪','⠳','⠻','⠘','⠸', ":", ",", ' ']
		
a = []
r = remote("instances.challenge-ecw.fr", 40276)
r.recvline()
r.recvline()
r.sendline(b"yes")
a.append("yes")
r.recvline()
r.sendline(b"42")
a.append("42")
s = r.recvline()
print(s)
if b"before" in s:
    r.sendline(chr(s[-2]-1).encode())
    a.append(chr(s[-2]-1))
elif b"after" in s:
    r.sendline(chr(s[-2]+1).encode())
    a.append(chr(s[-2]+1))
s = r.recvline().strip().decode()
print(s)
color = ast.literal_eval(s[s.rfind(":")+1:])
if webcolors.rgb_to_name(color) == "lime":
    r.sendline(b"green")
    a.append("green")
else:
    r.sendline(webcolors.rgb_to_name(color).encode())
    a.append(webcolors.rgb_to_name(color))
print(r.recvline())
r.recvline()
r.sendline(",".join(a).encode())
a.append(",".join(a))
s = r.recvline().decode()
print(s)
idx = (np.array(ast.literal_eval(s[s.rfind("(s) ")+4: s.rfind("using the same format")-1]))-1)
if type(idx.tolist()) == int:
    r.sendline(a[idx].encode())
    a.append(a[idx])
else:
    r.sendline(",".join(np.array(a)[idx]).encode())
    a.append(",".join(np.array(a)[idx]))
s = r.recvline().decode()

if "Can you tell me what color is" in s:
    color = ast.literal_eval(s[s.rfind(":")+1:])
    r.sendline(webcolors.rgb_to_name(color).encode())
    a.append(webcolors.rgb_to_name(color))
elif "Easy question, Which letter comes after" in s:
    r.sendline(chr(ord(s[-2])+1).encode())
    a.append(chr(ord(s[-2])+1))
elif "Easy question, Which letter comes before" in s:
    r.sendline(chr(ord(s[-2])-1).encode())
    a.append(chr(ord(s[-2])-1))
elif "I forgot everything. Send me back your answers to questions 1 to 4, separated by commas" in s:
    r.sendline(",".join(a[:4]).encode())
    a.append(",".join(a[:4]))
elif "What is the meaning of life" in s:
    r.sendline(b"42")
    a.append("42")
elif "Do you wanna play a game?" in s:
    r.sendline(b"yes")
    a.append("yes")
else:
    print(s)
print(r.recvline())

s = r.recvline().strip().decode()
s = s[3:]
print(s)

if s.startswith("..."):
    s = translator.Decoder().decode(s.replace("---... /", "")).plaintext
    print(s, s.replace("SEND ME BACK THE FOLLOWING WORD ", ""))
    s = s.replace("SEND ME BACK THE FOLLOWING WORD ", "")
    r.sendline(s.encode())
    a.append(s)
elif s.startswith("⠎"):
    s_new = ""
    for c in s.replace(" ", ""):
        s_new += asciicodes[brailles.index(c)]
    s = s_new.upper()
    s = s.replace("SEND ME BACK THE FOLLOWING WORD : ", "")
    print(s_new, s)
    r.sendline(s.encode())
    a.append(s)
else:
    print(s)
    r.sendline(b"NEURAL NETWORK")
    a.append("NEURAL NETWORK")

s = r.recv(2048)[3:]
with open("image.png", "wb") as f:
    f.write(s)
result = pyzbar.decode(Image.open('image.png'))
r.sendline(result[0].data[result[0].data.rfind(b":") + 2:])
a.append(result[0].data[result[0].data.rfind(b":") + 2:].decode())

s = r.recv(2**14)[4:]
with open("image.png", "wb") as f:
    f.write(s)
result = pyzbar.decode(Image.open('image.png'))
s = result[0].data.strip()

if s.startswith(b"\xe2\xa0\x81"):
    s = s.decode("utf-8").replace(" ⠀ ", "_").replace(" ", "").replace("_", " ")
else:
    s = s.decode()
    
if s.startswith(".-"):
    s = translator.Decoder().decode(s.replace("---... /", "")).plaintext.lower()
if s.startswith("⠁"):
    s_new = ""
    for c in s:
        s_new += asciicodes[brailles.index(c)]
    s = s_new[:]

if "you tell me what color is : " in s:
    color = ast.literal_eval(s[s.rfind(":")+2:])
    r.sendline(webcolors.rgb_to_name(color).encode())
    a.append(webcolors.rgb_to_name(color))
elif "you tell me what color is" in s:
    color = ast.literal_eval(s[s.rfind("is")+3:])
    r.sendline(webcolors.rgb_to_name(color).encode())
    a.append(webcolors.rgb_to_name(color))
elif "question, which letter comes after" in s:
    r.sendline(chr(ord(s[-1])+1).encode())
    a.append(chr(ord(s[-2])+1))
elif "question, which letter comes before" in s:
    r.sendline(chr(ord(s[-1])-1).encode())
    a.append(chr(ord(s[-2])-1))
elif "forgot everything. send me back your answers to questions 1 to 4, separated by commas" in s:
    r.sendline(",".join(a[:4]).encode())
    a.append(",".join(a[:4]))
elif "is the meaning of life" in s:
    r.sendline(b"42")
    a.append("42")
elif "you wanna play a game?" in s:
    r.sendline(b"yes")
    a.append("yes")
else:
    print(s)

print(r.recvline())